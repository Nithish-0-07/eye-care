import { useState } from "react"
import {
  Eye, Activity, Users, AlertTriangle, CheckCircle, Clock,
  Search, Bell, Settings, FileText, BarChart2,
  Home, LogOut, TrendingUp, Minus, ArrowRight, Zap,
  Info, Download, ChevronDown,
} from "lucide-react"
import {
  AreaChart, Area, XAxis, YAxis, Tooltip,
  ResponsiveContainer,
} from "recharts"

// ─── Data ────────────────────────────────────────────────────────────────────

const PATIENTS = [
  { id: 1, name: "Sarah Mitchell",   age: 67, gender: "F", eye: "Both",  risk: "high",     riskScore: 87, condition: "DR Stage III",        lastScan: "Today, 09:14", flag: true  },
  { id: 2, name: "James Okonkwo",    age: 54, gender: "M", eye: "Left",  risk: "moderate",  riskScore: 62, condition: "DR Stage II",          lastScan: "Today, 08:52", flag: false },
  { id: 3, name: "Elena Vasquez",    age: 71, gender: "F", eye: "Both",  risk: "low",       riskScore: 18, condition: "Healthy",              lastScan: "Today, 08:30", flag: false },
  { id: 4, name: "Robert Chen",      age: 59, gender: "M", eye: "Right", risk: "high",     riskScore: 79, condition: "Suspected Glaucoma",   lastScan: "Today, 10:05", flag: true  },
  { id: 5, name: "Amara Diallo",     age: 45, gender: "F", eye: "Both",  risk: "moderate",  riskScore: 55, condition: "Early AMD",            lastScan: "Today, 10:22", flag: false },
  { id: 6, name: "Patricia Holden",  age: 62, gender: "F", eye: "Right", risk: "low",       riskScore: 23, condition: "Healthy",              lastScan: "Today, 10:44", flag: false },
  { id: 7, name: "David Nakamura",   age: 50, gender: "M", eye: "Left",  risk: "low",       riskScore: 12, condition: "Healthy",              lastScan: "Today, 11:03", flag: false },
  { id: 8, name: "Fatima Al-Rashid", age: 58, gender: "F", eye: "Both",  risk: "high",     riskScore: 91, condition: "DR Stage IV",           lastScan: "Today, 11:18", flag: true  },
]

const TREND_DATA = [
  { day: "Mon", high: 5,  moderate: 8,  low: 22 },
  { day: "Tue", high: 7,  moderate: 11, low: 28 },
  { day: "Wed", high: 4,  moderate: 9,  low: 31 },
  { day: "Thu", high: 9,  moderate: 13, low: 24 },
  { day: "Fri", high: 6,  moderate: 10, low: 29 },
  { day: "Sat", high: 3,  moderate: 7,  low: 18 },
  { day: "Sun", high: 8,  moderate: 12, low: 27 },
]

const ALERTS = [
  { id: 1, patient: "Fatima Al-Rashid", message: "Critical: Stage IV DR detected — urgent referral required",         time: "11:18 AM", severity: "critical" },
  { id: 2, patient: "Sarah Mitchell",   message: "High-risk result confirmed by AI — ophthalmologist notified",       time: "09:32 AM", severity: "high"     },
  { id: 3, patient: "Robert Chen",      message: "Elevated IOP indicators — glaucoma screening recommended",          time: "10:07 AM", severity: "moderate"  },
]

// ─── Helpers ─────────────────────────────────────────────────────────────────

type Patient = typeof PATIENTS[number]
type Risk = "high" | "moderate" | "low"

const riskPalette: Record<Risk, { bg: string; text: string; bar: string; border: string }> = {
  high:     { bg: "#FEF2F2", text: "#DC2626", bar: "#DC2626", border: "#FECACA" },
  moderate: { bg: "#FFFBEB", text: "#D97706", bar: "#D97706", border: "#FDE68A" },
  low:      { bg: "#F0FDF4", text: "#16A34A", bar: "#16A34A", border: "#BBF7D0" },
}

const initials = (name: string) =>
  name.split(" ").map(n => n[0]).join("").slice(0, 2)

const avatarGradients: Record<Risk, string> = {
  high:     "linear-gradient(135deg,#FCA5A5,#DC2626)",
  moderate: "linear-gradient(135deg,#FCD34D,#D97706)",
  low:      "linear-gradient(135deg,#6EE7B7,#059669)",
}

// ─── Sub-components ──────────────────────────────────────────────────────────

function RetinalSVG({ risk }: { risk: Risk }) {
  return (
    <div
      style={{
        position: "relative",
        backgroundColor: "#080810",
        borderRadius: 10,
        overflow: "hidden",
        aspectRatio: "4/3",
        marginBottom: 10,
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
      }}
    >
      <svg width="200" height="200" viewBox="0 0 200 200" style={{ position: "relative", zIndex: 1 }}>
        {/* Fundus background */}
        <defs>
          <radialGradient id="fundus" cx="55%" cy="45%" r="50%">
            <stop offset="0%"   stopColor="#C04000" />
            <stop offset="40%"  stopColor="#5A1800" />
            <stop offset="80%"  stopColor="#280800" />
            <stop offset="100%" stopColor="#0A0308" />
          </radialGradient>
          <clipPath id="eyeClip">
            <circle cx="100" cy="100" r="98" />
          </clipPath>
        </defs>
        <circle cx="100" cy="100" r="98" fill="url(#fundus)" />

        {/* Major vessels */}
        <g clipPath="url(#eyeClip)" stroke="#7A1010" fill="none" strokeLinecap="round">
          <path d="M 115 93 Q 82 112 57 142 Q 42 162 30 177" strokeWidth="2.2" opacity="0.85" />
          <path d="M 115 93 Q 100 122 86 152 Q 76 167 72 181" strokeWidth="1.6" opacity="0.75" />
          <path d="M 115 93 Q 138 108 163 128 Q 178 143 190 159" strokeWidth="2.0" opacity="0.85" />
          <path d="M 115 93 Q 132 78 157 63 Q 172 53 184 43"   strokeWidth="1.7" opacity="0.75" />
          <path d="M 115 93 Q 92 80  67 70  Q 47 62  28 54"    strokeWidth="1.5" opacity="0.65" />
          <path d="M 115 93 Q 106 74 101 50 Q 98 30  99 14"    strokeWidth="1.5" opacity="0.65" />
          {/* Finer branches */}
          <path d="M 75 138 Q 65 150 52 158" strokeWidth="1.0" opacity="0.55" />
          <path d="M 148 128 Q 160 138 168 150" strokeWidth="1.0" opacity="0.55" />
        </g>

        {/* Optic disc */}
        <ellipse cx="116" cy="92" rx="15" ry="18" fill="url(#disc)" opacity="0.92" />
        <defs>
          <radialGradient id="disc" cx="50%" cy="40%" r="50%">
            <stop offset="0%"   stopColor="#FFE090" />
            <stop offset="60%"  stopColor="#FFB040" />
            <stop offset="100%" stopColor="#E08020" />
          </radialGradient>
        </defs>

        {/* Macula */}
        <circle cx="83" cy="107" r="19" fill="none" stroke="rgba(90,25,0,0.35)" strokeWidth="1.2" />
        <circle cx="83" cy="107" r="3"  fill="rgba(50,8,0,0.9)" />

        {/* Pathological lesions */}
        {risk === "high" && (
          <>
            <circle cx="68"  cy="132" r="6.5" fill="rgba(255,225,0,0.65)" />
            <circle cx="147" cy="122" r="5.5" fill="rgba(255,225,0,0.55)" />
            <circle cx="78"  cy="68"  r="4.5" fill="rgba(255,225,0,0.45)" />
            <circle cx="58"  cy="103" r="3.5" fill="rgba(255,255,255,0.35)" />
            <circle cx="158" cy="152" r="4.5" fill="rgba(255,225,0,0.45)" />
            <circle cx="105" cy="155" r="3.0" fill="rgba(255,225,0,0.40)" />
          </>
        )}
        {risk === "moderate" && (
          <>
            <circle cx="74"  cy="128" r="4.5" fill="rgba(255,225,0,0.45)" />
            <circle cx="152" cy="118" r="3.5" fill="rgba(255,225,0,0.40)" />
          </>
        )}

        {/* Edge vignette */}
        <circle cx="100" cy="100" r="98" fill="none" stroke="rgba(0,0,0,0.55)" strokeWidth="8" />
      </svg>

      {/* Overlay badges */}
      <div style={{ position: "absolute", top: 8, left: 8, display: "flex", gap: 5 }}>
        <span style={{ background: "rgba(0,0,0,0.6)", color: "#94A3B8", fontSize: 9, padding: "2px 7px", borderRadius: 4, fontWeight: 700, letterSpacing: "0.06em" }}>OD</span>
        <span style={{ background: "rgba(26,95,173,0.85)", color: "white", fontSize: 9, padding: "2px 7px", borderRadius: 4, fontWeight: 700 }}>AI PROCESSED</span>
      </div>
      {risk === "high" && (
        <div style={{ position: "absolute", top: 8, right: 8 }}>
          <span style={{ background: "rgba(220,38,38,0.88)", color: "white", fontSize: 9, padding: "2px 8px", borderRadius: 4, fontWeight: 700 }}>LESIONS DETECTED</span>
        </div>
      )}
      <div style={{ position: "absolute", bottom: 8, right: 8 }}>
        <span style={{ background: "rgba(0,0,0,0.55)", color: "#94A3B8", fontSize: 9, padding: "2px 7px", borderRadius: 4 }}>45° · 5 MP</span>
      </div>
    </div>
  )
}

// ─── Main component ───────────────────────────────────────────────────────────

export default function App() {
  const [selectedPatient, setSelectedPatient] = useState<Patient>(PATIENTS[0])
  const [activeNav, setActiveNav]             = useState("dashboard")
  const [searchQuery, setSearchQuery]         = useState("")
  const [filterRisk, setFilterRisk]           = useState("all")
  const [activeTab, setActiveTab]             = useState("scan")

  const filtered = PATIENTS.filter(p => {
    const q = searchQuery.toLowerCase()
    const matchSearch = p.name.toLowerCase().includes(q) || p.condition.toLowerCase().includes(q)
    const matchRisk   = filterRisk === "all" || p.risk === filterRisk
    return matchSearch && matchRisk
  })

  const palette = riskPalette[selectedPatient.risk as Risk]

  // ── Nav items ──
  const navMain = [
    { id: "dashboard",  label: "Dashboard",  icon: Home,     badge: 0 },
    { id: "patients",   label: "Patients",   icon: Users,    badge: 3 },
    { id: "screenings", label: "Screenings", icon: Eye,      badge: 0 },
    { id: "reports",    label: "Reports",    icon: FileText, badge: 0 },
    { id: "analytics",  label: "Analytics",  icon: BarChart2,badge: 0 },
  ]

  return (
    <div style={{ display: "flex", height: "100vh", fontFamily: "'Plus Jakarta Sans', system-ui, sans-serif", backgroundColor: "#EEF4FF", overflow: "hidden" }}>

      {/* ── Sidebar ──────────────────────────────────────────── */}
      <aside style={{ width: 240, backgroundColor: "#0B1E38", display: "flex", flexDirection: "column", flexShrink: 0 }}>

        {/* Logo */}
        <div style={{ padding: "22px 20px 18px", borderBottom: "1px solid rgba(255,255,255,0.07)" }}>
          <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
            <div style={{ width: 36, height: 36, borderRadius: 10, background: "linear-gradient(135deg,#1A7BF5,#0E9583)", display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0 }}>
              <Eye size={18} color="white" />
            </div>
            <div>
              <div style={{ color: "white", fontWeight: 800, fontSize: 14, lineHeight: 1.2 }}>RetinaCare</div>
              <div style={{ color: "#64A0E0", fontSize: 10, fontWeight: 500, letterSpacing: "0.04em" }}>AI Screening</div>
            </div>
          </div>
        </div>

        {/* Nav */}
        <nav style={{ flex: 1, padding: "14px 10px", overflowY: "auto" }}>
          <div style={{ color: "#3D6896", fontSize: 9.5, fontWeight: 700, letterSpacing: "0.1em", padding: "0 8px 10px", textTransform: "uppercase" }}>
            Main Menu
          </div>
          {navMain.map(item => {
            const active = activeNav === item.id
            return (
              <button
                key={item.id}
                onClick={() => setActiveNav(item.id)}
                style={{
                  width: "100%", display: "flex", alignItems: "center", gap: 9,
                  padding: "8px 10px", borderRadius: 8, marginBottom: 2,
                  backgroundColor: active ? "rgba(26,123,245,0.14)" : "transparent",
                  color: active ? "#60A5FA" : "#7AABD4",
                  border: "none", cursor: "pointer", fontSize: 13, fontWeight: active ? 700 : 400,
                  textAlign: "left", transition: "background 0.15s, color 0.15s",
                }}
              >
                <item.icon size={15} style={{ flexShrink: 0 }} />
                <span style={{ flex: 1 }}>{item.label}</span>
                {item.badge > 0 && (
                  <span style={{ backgroundColor: "#DC2626", color: "white", fontSize: 9.5, fontWeight: 800, borderRadius: 10, padding: "1px 6px" }}>
                    {item.badge}
                  </span>
                )}
              </button>
            )
          })}

          <div style={{ marginTop: 20, color: "#3D6896", fontSize: 9.5, fontWeight: 700, letterSpacing: "0.1em", padding: "0 8px 10px", textTransform: "uppercase" }}>
            System
          </div>
          <button
            onClick={() => setActiveNav("settings")}
            style={{
              width: "100%", display: "flex", alignItems: "center", gap: 9,
              padding: "8px 10px", borderRadius: 8,
              backgroundColor: activeNav === "settings" ? "rgba(26,123,245,0.14)" : "transparent",
              color: activeNav === "settings" ? "#60A5FA" : "#7AABD4",
              border: "none", cursor: "pointer", fontSize: 13, fontWeight: 400, textAlign: "left",
            }}
          >
            <Settings size={15} />
            <span>Settings</span>
          </button>
        </nav>

        {/* Critical alert banner */}
        <div style={{ margin: "0 10px 10px", background: "rgba(220,38,38,0.11)", border: "1px solid rgba(220,38,38,0.22)", borderRadius: 10, padding: "9px 11px" }}>
          <div style={{ display: "flex", alignItems: "center", gap: 7, marginBottom: 3 }}>
            <AlertTriangle size={12} color="#F87171" />
            <span style={{ color: "#F87171", fontSize: 11, fontWeight: 700 }}>3 Critical Alerts</span>
          </div>
          <p style={{ color: "#7AABD4", fontSize: 10.5, margin: 0, lineHeight: 1.4 }}>Urgent referrals required today</p>
        </div>

        {/* User profile */}
        <div style={{ borderTop: "1px solid rgba(255,255,255,0.07)", padding: "11px 14px", display: "flex", alignItems: "center", gap: 9 }}>
          <div style={{ width: 32, height: 32, borderRadius: 8, background: "linear-gradient(135deg,#2563EB,#0E9583)", display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0 }}>
            <span style={{ color: "white", fontSize: 11, fontWeight: 800 }}>DR</span>
          </div>
          <div style={{ flex: 1, minWidth: 0 }}>
            <div style={{ color: "white", fontSize: 12, fontWeight: 700, whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>Dr. A. Rahman</div>
            <div style={{ color: "#64A0E0", fontSize: 10 }}>Ophthalmologist</div>
          </div>
          <LogOut size={13} color="#3D6896" style={{ cursor: "pointer", flexShrink: 0 }} />
        </div>
      </aside>

      {/* ── Main ─────────────────────────────────────────────── */}
      <main style={{ flex: 1, display: "flex", flexDirection: "column", overflow: "hidden" }}>

        {/* Top bar */}
        <header style={{ backgroundColor: "white", borderBottom: "1px solid #E2E8F0", padding: "0 24px", height: 62, display: "flex", alignItems: "center", justifyContent: "space-between", flexShrink: 0 }}>
          <div>
            <h1 style={{ margin: 0, fontSize: 16, fontWeight: 800, color: "#0F172A", letterSpacing: "-0.02em" }}>Patient Dashboard</h1>
            <p style={{ margin: 0, fontSize: 11.5, color: "#64748B", fontWeight: 400 }}>Friday, 9 October 2026 — Morning Clinic</p>
          </div>
          <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
            {/* Search */}
            <div style={{ display: "flex", alignItems: "center", gap: 8, backgroundColor: "#F1F5F9", borderRadius: 9, padding: "7px 12px", width: 210 }}>
              <Search size={13} color="#94A3B8" />
              <input
                placeholder="Search patients…"
                value={searchQuery}
                onChange={e => setSearchQuery(e.target.value)}
                style={{ border: "none", background: "transparent", fontSize: 12.5, color: "#0F172A", outline: "none", width: "100%", fontFamily: "inherit" }}
              />
            </div>
            {/* Bell */}
            <div style={{ position: "relative" }}>
              <button style={{ width: 36, height: 36, borderRadius: 9, border: "1px solid #E2E8F0", background: "white", display: "flex", alignItems: "center", justifyContent: "center", cursor: "pointer" }}>
                <Bell size={14} color="#64748B" />
              </button>
              <div style={{ position: "absolute", top: 7, right: 7, width: 7, height: 7, borderRadius: "50%", backgroundColor: "#DC2626", border: "2px solid white" }} />
            </div>
            {/* Download */}
            <button style={{ display: "flex", alignItems: "center", gap: 5, backgroundColor: "white", color: "#1A5FAD", border: "1px solid #BFDBFE", borderRadius: 9, padding: "7px 12px", fontSize: 12, fontWeight: 600, cursor: "pointer" }}>
              <Download size={13} />
              Export
            </button>
            {/* New scan CTA */}
            <button style={{ display: "flex", alignItems: "center", gap: 6, backgroundColor: "#1A5FAD", color: "white", border: "none", borderRadius: 9, padding: "8px 16px", fontSize: 12.5, fontWeight: 700, cursor: "pointer", letterSpacing: "-0.01em" }}>
              <Eye size={14} />
              New Scan
            </button>
          </div>
        </header>

        {/* Scrollable content */}
        <div style={{ flex: 1, overflow: "auto", padding: "18px 22px", display: "flex", flexDirection: "column", gap: 14 }}>

          {/* ── KPI row ─────────────────────────────────────── */}
          <div style={{ display: "grid", gridTemplateColumns: "repeat(4,1fr)", gap: 14 }}>
            {[
              { label: "Screened Today",    value: "47",    sub: "+12 vs yesterday",        icon: Eye,           iconColor: "#1A5FAD", iconBg: "#EFF6FF", trend: "up"      },
              { label: "High Risk Flagged", value: "8",     sub: "3 require urgent care",   icon: AlertTriangle, iconColor: "#DC2626", iconBg: "#FEF2F2", trend: "up"      },
              { label: "Pending Review",    value: "12",    sub: "5 queued over 1 hour",    icon: Clock,         iconColor: "#D97706", iconBg: "#FFFBEB", trend: "neutral" },
              { label: "AI Accuracy",       value: "94.2%", sub: "Based on 1,840 cases",    icon: Zap,           iconColor: "#0E9583", iconBg: "#F0FDFA", trend: "up"      },
            ].map((kpi, i) => (
              <div key={i} style={{ backgroundColor: "white", borderRadius: 14, padding: "15px 16px", border: "1px solid #E2E8F0", boxShadow: "0 1px 4px rgba(15,23,42,0.04)" }}>
                <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: 10 }}>
                  <div style={{ width: 36, height: 36, borderRadius: 9, backgroundColor: kpi.iconBg, display: "flex", alignItems: "center", justifyContent: "center" }}>
                    <kpi.icon size={17} color={kpi.iconColor} />
                  </div>
                  {kpi.trend === "up"      && <TrendingUp size={13} color="#16A34A" />}
                  {kpi.trend === "neutral" && <Minus      size={13} color="#94A3B8" />}
                </div>
                <div style={{ fontSize: 22, fontWeight: 800, color: "#0F172A", marginBottom: 1, letterSpacing: "-0.03em" }}>{kpi.value}</div>
                <div style={{ fontSize: 11.5, color: "#475569", marginBottom: 3, fontWeight: 600 }}>{kpi.label}</div>
                <div style={{ fontSize: 10.5, color: "#94A3B8" }}>{kpi.sub}</div>
              </div>
            ))}
          </div>

          {/* ── Middle row: Queue + AI panel ─────────────────── */}
          <div style={{ display: "grid", gridTemplateColumns: "1fr 330px", gap: 14 }}>

            {/* Patient Queue */}
            <div style={{ backgroundColor: "white", borderRadius: 14, border: "1px solid #E2E8F0", boxShadow: "0 1px 4px rgba(15,23,42,0.04)", overflow: "hidden" }}>
              <div style={{ padding: "13px 16px", borderBottom: "1px solid #F1F5F9", display: "flex", justifyContent: "space-between", alignItems: "center" }}>
                <h3 style={{ margin: 0, fontSize: 13.5, fontWeight: 800, color: "#0F172A" }}>
                  Patient Queue
                  <span style={{ marginLeft: 8, fontSize: 11, fontWeight: 600, color: "#94A3B8", backgroundColor: "#F1F5F9", padding: "1px 7px", borderRadius: 10 }}>{filtered.length}</span>
                </h3>
                <div style={{ display: "flex", gap: 6 }}>
                  {(["all","high","moderate","low"] as const).map(f => (
                    <button
                      key={f}
                      onClick={() => setFilterRisk(f)}
                      style={{
                        padding: "3px 9px", borderRadius: 7, fontSize: 10.5, fontWeight: 700, cursor: "pointer",
                        border: "1px solid", textTransform: "capitalize",
                        borderColor: filterRisk === f ? "#1A5FAD" : "#E2E8F0",
                        backgroundColor: filterRisk === f ? "#EFF6FF" : "white",
                        color: filterRisk === f ? "#1A5FAD" : "#64748B",
                      }}
                    >
                      {f === "all" ? "All" : f}
                    </button>
                  ))}
                </div>
              </div>
              <div style={{ overflowX: "auto" }}>
                <table style={{ width: "100%", borderCollapse: "collapse" }}>
                  <thead>
                    <tr style={{ borderBottom: "1px solid #F1F5F9" }}>
                      {["Patient","Age / Sex","Condition","AI Score","Last Scan","Risk"].map(h => (
                        <th key={h} style={{ padding: "8px 12px", textAlign: "left", fontSize: 10.5, color: "#94A3B8", fontWeight: 700, whiteSpace: "nowrap", letterSpacing: "0.03em" }}>{h}</th>
                      ))}
                    </tr>
                  </thead>
                  <tbody>
                    {filtered.map(p => {
                      const pal = riskPalette[p.risk as Risk]
                      const isSelected = selectedPatient.id === p.id
                      return (
                        <tr
                          key={p.id}
                          onClick={() => setSelectedPatient(p)}
                          style={{
                            borderBottom: "1px solid #F8FAFC", cursor: "pointer",
                            backgroundColor: isSelected ? "#F0F7FF" : "transparent",
                            transition: "background 0.1s",
                          }}
                        >
                          {/* Name */}
                          <td style={{ padding: "9px 12px" }}>
                            <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
                              <div style={{ width: 29, height: 29, borderRadius: 7, background: avatarGradients[p.risk as Risk], display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0 }}>
                                <span style={{ color: "white", fontSize: 9.5, fontWeight: 800 }}>{initials(p.name)}</span>
                              </div>
                              <div>
                                <div style={{ fontSize: 12, fontWeight: 700, color: "#0F172A" }}>{p.name}</div>
                                {p.flag && <div style={{ fontSize: 9.5, color: "#DC2626", fontWeight: 600 }}>⚑ Flagged</div>}
                              </div>
                            </div>
                          </td>
                          {/* Age / sex */}
                          <td style={{ padding: "9px 12px", fontSize: 12, color: "#64748B" }}>{p.age} / {p.gender}</td>
                          {/* Condition */}
                          <td style={{ padding: "9px 12px", fontSize: 12, color: "#0F172A", fontWeight: 500 }}>{p.condition}</td>
                          {/* Score bar */}
                          <td style={{ padding: "9px 12px" }}>
                            <div style={{ display: "flex", alignItems: "center", gap: 6 }}>
                              <div style={{ flex: 1, height: 5, backgroundColor: "#F1F5F9", borderRadius: 3, minWidth: 48 }}>
                                <div style={{ height: "100%", width: `${p.riskScore}%`, backgroundColor: pal.bar, borderRadius: 3, transition: "width 0.3s" }} />
                              </div>
                              <span style={{ fontSize: 11, fontWeight: 800, color: pal.bar, minWidth: 24, fontFamily: "'JetBrains Mono', monospace" }}>{p.riskScore}</span>
                            </div>
                          </td>
                          {/* Scan time */}
                          <td style={{ padding: "9px 12px", fontSize: 11, color: "#64748B", whiteSpace: "nowrap", fontFamily: "'JetBrains Mono', monospace" }}>{p.lastScan}</td>
                          {/* Badge */}
                          <td style={{ padding: "9px 12px" }}>
                            <span style={{ backgroundColor: pal.bg, color: pal.text, fontSize: 10, fontWeight: 800, padding: "3px 8px", borderRadius: 6, whiteSpace: "nowrap" }}>
                              {p.risk === "low" ? "Low Risk" : p.risk === "moderate" ? "Moderate" : "High Risk"}
                            </span>
                          </td>
                        </tr>
                      )
                    })}
                  </tbody>
                </table>
              </div>
            </div>

            {/* AI Risk Assessment */}
            <div style={{ backgroundColor: "white", borderRadius: 14, border: "1px solid #E2E8F0", boxShadow: "0 1px 4px rgba(15,23,42,0.04)", overflow: "hidden", display: "flex", flexDirection: "column" }}>
              <div style={{ padding: "13px 16px", borderBottom: "1px solid #F1F5F9" }}>
                <h3 style={{ margin: 0, fontSize: 13.5, fontWeight: 800, color: "#0F172A" }}>AI Assessment</h3>
                <p style={{ margin: "2px 0 0", fontSize: 11.5, color: "#64748B" }}>{selectedPatient.name}</p>
              </div>
              <div style={{ padding: "14px 16px", flex: 1, display: "flex", flexDirection: "column" }}>

                {/* Gauge */}
                <div style={{ textAlign: "center", marginBottom: 14 }}>
                  <svg width="150" height="84" viewBox="0 0 150 84" style={{ overflow: "visible" }}>
                    {/* Track */}
                    <path d="M 18 79 A 57 57 0 0 1 132 79" fill="none" stroke="#F1F5F9" strokeWidth="13" strokeLinecap="round" />
                    {/* Value arc — length of semicircle ≈ π × r = 179 */}
                    <path
                      d="M 18 79 A 57 57 0 0 1 132 79"
                      fill="none"
                      stroke={palette.bar}
                      strokeWidth="13"
                      strokeLinecap="round"
                      strokeDasharray={`${(selectedPatient.riskScore / 100) * 179} 179`}
                      style={{ transition: "stroke-dasharray 0.4s, stroke 0.3s" }}
                    />
                    <text x="75" y="69" textAnchor="middle" fontSize="24" fontWeight="800" fill="#0F172A" fontFamily="'Plus Jakarta Sans', sans-serif" letterSpacing="-1">
                      {selectedPatient.riskScore}
                    </text>
                    <text x="75" y="79" textAnchor="middle" fontSize="8.5" fill="#94A3B8" fontFamily="'Plus Jakarta Sans', sans-serif" fontWeight="700" letterSpacing="0.08em">
                      RISK SCORE
                    </text>
                  </svg>
                  <span style={{ backgroundColor: palette.bg, color: palette.text, fontSize: 11, fontWeight: 800, padding: "4px 14px", borderRadius: 20, display: "inline-block", marginTop: -4 }}>
                    {selectedPatient.risk === "high" ? "High Risk" : selectedPatient.risk === "moderate" ? "Moderate Risk" : "Low Risk"}
                  </span>
                </div>

                {/* Detail rows */}
                <div style={{ display: "flex", flexDirection: "column", gap: 6, marginBottom: 12 }}>
                  {[
                    { label: "Primary Finding", value: selectedPatient.condition },
                    { label: "Eye(s) Affected", value: selectedPatient.eye       },
                    { label: "Last Scan",        value: selectedPatient.lastScan  },
                    { label: "AI Confidence",    value: "97.4%"                   },
                  ].map((row, i) => (
                    <div key={i} style={{ display: "flex", justifyContent: "space-between", alignItems: "center", padding: "6px 9px", backgroundColor: "#F8FAFC", borderRadius: 8 }}>
                      <span style={{ fontSize: 11, color: "#64748B", fontWeight: 500 }}>{row.label}</span>
                      <span style={{ fontSize: 11, color: "#0F172A", fontWeight: 700, fontFamily: row.label === "AI Confidence" || row.label === "Last Scan" ? "'JetBrains Mono', monospace" : "inherit" }}>{row.value}</span>
                    </div>
                  ))}
                </div>

                {/* Recommendation */}
                {selectedPatient.risk === "high" && (
                  <div style={{ padding: "9px 11px", backgroundColor: "#FEF2F2", border: `1px solid ${palette.border}`, borderRadius: 9, marginBottom: 10 }}>
                    <div style={{ display: "flex", gap: 6, alignItems: "flex-start" }}>
                      <AlertTriangle size={12} color="#DC2626" style={{ marginTop: 1, flexShrink: 0 }} />
                      <div>
                        <div style={{ fontSize: 11, fontWeight: 800, color: "#DC2626", marginBottom: 2 }}>Urgent Referral Required</div>
                        <div style={{ fontSize: 10.5, color: "#7F1D1D", lineHeight: 1.4 }}>Immediate ophthalmology consultation recommended</div>
                      </div>
                    </div>
                  </div>
                )}
                {selectedPatient.risk === "moderate" && (
                  <div style={{ padding: "9px 11px", backgroundColor: "#FFFBEB", border: `1px solid ${palette.border}`, borderRadius: 9, marginBottom: 10 }}>
                    <div style={{ display: "flex", gap: 6, alignItems: "flex-start" }}>
                      <Info size={12} color="#D97706" style={{ marginTop: 1, flexShrink: 0 }} />
                      <div>
                        <div style={{ fontSize: 11, fontWeight: 800, color: "#D97706", marginBottom: 2 }}>Follow-up Needed</div>
                        <div style={{ fontSize: 10.5, color: "#78350F", lineHeight: 1.4 }}>Schedule 3-month monitoring appointment</div>
                      </div>
                    </div>
                  </div>
                )}
                {selectedPatient.risk === "low" && (
                  <div style={{ padding: "9px 11px", backgroundColor: "#F0FDF4", border: `1px solid ${palette.border}`, borderRadius: 9, marginBottom: 10 }}>
                    <div style={{ display: "flex", gap: 6, alignItems: "flex-start" }}>
                      <CheckCircle size={12} color="#16A34A" style={{ marginTop: 1, flexShrink: 0 }} />
                      <div>
                        <div style={{ fontSize: 11, fontWeight: 800, color: "#16A34A", marginBottom: 2 }}>No Immediate Action</div>
                        <div style={{ fontSize: 10.5, color: "#14532D", lineHeight: 1.4 }}>Annual screening is sufficient</div>
                      </div>
                    </div>
                  </div>
                )}

                <button style={{ width: "100%", padding: "9px", backgroundColor: "#1A5FAD", color: "white", border: "none", borderRadius: 9, fontSize: 12.5, fontWeight: 700, cursor: "pointer", display: "flex", alignItems: "center", justifyContent: "center", gap: 6, marginTop: "auto" }}>
                  View Full Report <ArrowRight size={13} />
                </button>
              </div>
            </div>
          </div>

          {/* ── Bottom row: Retinal viewer + Trend + Alerts ───── */}
          <div style={{ display: "grid", gridTemplateColumns: "360px 1fr", gap: 14 }}>

            {/* Retinal Scan Viewer */}
            <div style={{ backgroundColor: "white", borderRadius: 14, border: "1px solid #E2E8F0", boxShadow: "0 1px 4px rgba(15,23,42,0.04)", overflow: "hidden" }}>
              <div style={{ padding: "11px 14px", borderBottom: "1px solid #F1F5F9", display: "flex", justifyContent: "space-between", alignItems: "center" }}>
                <h3 style={{ margin: 0, fontSize: 13, fontWeight: 800, color: "#0F172A" }}>Retinal Scan</h3>
                <div style={{ display: "flex", gap: 5 }}>
                  {["scan","analysis","history"].map(tab => (
                    <button
                      key={tab}
                      onClick={() => setActiveTab(tab)}
                      style={{
                        padding: "3px 10px", borderRadius: 7, fontSize: 10.5, fontWeight: 700, cursor: "pointer",
                        border: "none", textTransform: "capitalize",
                        backgroundColor: activeTab === tab ? "#1A5FAD" : "#F1F5F9",
                        color:           activeTab === tab ? "white"   : "#64748B",
                      }}
                    >
                      {tab}
                    </button>
                  ))}
                </div>
              </div>
              <div style={{ padding: "12px 14px" }}>
                <RetinalSVG risk={selectedPatient.risk as Risk} />
                {/* Findings chips */}
                <div style={{ display: "flex", gap: 8 }}>
                  {[
                    { label: "Optic Disc", ok: true                                    },
                    { label: "Macula",     ok: selectedPatient.risk !== "high"          },
                    { label: "Vasculature",ok: selectedPatient.risk === "low"           },
                  ].map((f, i) => (
                    <div
                      key={i}
                      style={{
                        flex: 1, padding: "7px 0", textAlign: "center",
                        backgroundColor: f.ok ? "#F0FDF4" : "#FEF2F2",
                        borderRadius: 8, border: `1px solid ${f.ok ? "#BBF7D0" : "#FECACA"}`,
                      }}
                    >
                      <div style={{ fontSize: 13, lineHeight: 1 }}>{f.ok ? "✓" : "⚠"}</div>
                      <div style={{ fontSize: 9.5, color: f.ok ? "#16A34A" : "#DC2626", fontWeight: 700, marginTop: 2 }}>{f.label}</div>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            {/* Right column: chart + alerts */}
            <div style={{ display: "flex", flexDirection: "column", gap: 14 }}>

              {/* Weekly Risk Distribution */}
              <div style={{ backgroundColor: "white", borderRadius: 14, border: "1px solid #E2E8F0", boxShadow: "0 1px 4px rgba(15,23,42,0.04)", padding: "13px 16px", flex: 1 }}>
                <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 12 }}>
                  <h3 style={{ margin: 0, fontSize: 13, fontWeight: 800, color: "#0F172A" }}>Weekly Risk Distribution</h3>
                  <div style={{ display: "flex", gap: 12 }}>
                    {[{ label: "High", color: "#DC2626" },{ label: "Moderate", color: "#D97706" },{ label: "Low", color: "#16A34A" }].map(l => (
                      <div key={l.label} style={{ display: "flex", alignItems: "center", gap: 4, fontSize: 10.5, color: "#64748B", fontWeight: 600 }}>
                        <div style={{ width: 8, height: 8, borderRadius: 2, backgroundColor: l.color }} />
                        {l.label}
                      </div>
                    ))}
                  </div>
                </div>
                <ResponsiveContainer width="100%" height={90}>
                  <AreaChart data={TREND_DATA} margin={{ top: 2, right: 0, left: -28, bottom: 0 }}>
                    <defs>
                      {[["highG","#DC2626"],["modG","#D97706"],["lowG","#16A34A"]].map(([id, col]) => (
                        <linearGradient key={id} id={id} x1="0" y1="0" x2="0" y2="1">
                          <stop offset="5%"  stopColor={col} stopOpacity={0.18} />
                          <stop offset="95%" stopColor={col} stopOpacity={0}    />
                        </linearGradient>
                      ))}
                    </defs>
                    <XAxis dataKey="day" tick={{ fontSize: 9.5, fill: "#94A3B8" }} axisLine={false} tickLine={false} />
                    <YAxis tick={{ fontSize: 9.5, fill: "#94A3B8" }} axisLine={false} tickLine={false} />
                    <Tooltip
                      contentStyle={{ fontSize: 11, borderRadius: 9, border: "1px solid #E2E8F0", boxShadow: "0 3px 10px rgba(0,0,0,0.07)", fontFamily: "'Plus Jakarta Sans', sans-serif" }}
                      cursor={{ stroke: "#E2E8F0", strokeWidth: 1 }}
                    />
                    <Area type="monotone" dataKey="high"     stroke="#DC2626" fill="url(#highG)" strokeWidth={2} dot={false} />
                    <Area type="monotone" dataKey="moderate" stroke="#D97706" fill="url(#modG)"  strokeWidth={2} dot={false} />
                    <Area type="monotone" dataKey="low"      stroke="#16A34A" fill="url(#lowG)"  strokeWidth={2} dot={false} />
                  </AreaChart>
                </ResponsiveContainer>
              </div>

              {/* Recent Alerts */}
              <div style={{ backgroundColor: "white", borderRadius: 14, border: "1px solid #E2E8F0", boxShadow: "0 1px 4px rgba(15,23,42,0.04)", overflow: "hidden" }}>
                <div style={{ padding: "11px 16px", borderBottom: "1px solid #F1F5F9", display: "flex", justifyContent: "space-between", alignItems: "center" }}>
                  <h3 style={{ margin: 0, fontSize: 13, fontWeight: 800, color: "#0F172A" }}>Recent Alerts</h3>
                  <button style={{ fontSize: 11, color: "#1A5FAD", fontWeight: 700, border: "none", background: "none", cursor: "pointer" }}>View All</button>
                </div>
                <div>
                  {ALERTS.map((alert, i) => {
                    const dotColor = alert.severity === "critical" ? "#DC2626" : alert.severity === "high" ? "#D97706" : "#0E9583"
                    return (
                      <div
                        key={alert.id}
                        style={{
                          padding: "9px 16px", display: "flex", gap: 10, alignItems: "flex-start",
                          borderBottom: i < ALERTS.length - 1 ? "1px solid #F8FAFC" : "none",
                        }}
                      >
                        <div style={{ width: 8, height: 8, borderRadius: "50%", marginTop: 5, flexShrink: 0, backgroundColor: dotColor, boxShadow: `0 0 0 2px ${dotColor}22` }} />
                        <div style={{ flex: 1, minWidth: 0 }}>
                          <div style={{ fontSize: 12, fontWeight: 700, color: "#0F172A", marginBottom: 1 }}>{alert.patient}</div>
                          <div style={{ fontSize: 11, color: "#64748B", lineHeight: 1.45 }}>{alert.message}</div>
                        </div>
                        <div style={{ fontSize: 9.5, color: "#94A3B8", whiteSpace: "nowrap", flexShrink: 0, fontFamily: "'JetBrains Mono', monospace" }}>{alert.time}</div>
                      </div>
                    )
                  })}
                </div>
              </div>
            </div>
          </div>
        </div>
      </main>
    </div>
  )
}
